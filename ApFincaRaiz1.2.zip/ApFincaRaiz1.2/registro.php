<?php

/* 
 * Cliente: A&P Finca Raiz.
 * Creado por: Interactive group. Julián Lozano.
 * Fecha: 2017
 */

$mysqli = new mysqli('localhost', 'root', 'root', 'apfinca_raiz');
require 'funcs/funcs.php';

$errors = array();
$succes = array();

if (!empty($_POST)){
    $nombre = $mysqli->real_escape_string($_POST['nombre']);
    $apellidos = $mysqli->real_escape_string($_POST['apellidos']);
    $cedula = $mysqli->real_escape_string($_POST['cedula']);
    $telefono = $mysqli->real_escape_string($_POST['telefono']);
    $password = $mysqli->real_escape_string($_POST['password']);
    $con_password = $mysqli->real_escape_string($_POST['con_password']);
    $email = $mysqli->real_escape_string($_POST['email']);
    $tipoperfil = $mysqli->real_escape_string($_POST['perfil']);
    
    
    //var_dump($_POST);
    
    if(isNull($nombre, $apellidos, $cedula, $telefono, $email, $password, $con_password, $tipoperfil)){
        $errors[]= "Debe llenar todos los campos"; 
    }
    if(!isEmail($email)){
        $errors[]= "Dirección de correo invalida";
    }
    if(!validaPassword($password, $con_password)){
        $errors[]= "Las contraseñas no coinciden";
    }
    
    if(count($errors == 0)){
        
        $registro = registraUsuario($nombre, $apellidos, $cedula, $telefono, $email, $password, $tipoperfil);
        //var_dump($registro);
        
        if($registro > 0 ){
            $registroPerfil = registraPerfil($cedula, $tipoperfil);
            var_dump($registroPerfil);
            $succes[] = "Registro de usuario exitoso";
            if($registroPerfil > 0){
                $succes[] = "Registro del perfil exitoso";
            } else {
                $errors[]= "Error al registrar el perfil del usuario";
            }
        }else {
            $errors[]= "Error al registrar el usuario";
            //echo "Falló la preparación: (" . $errormysql . ") ";
        }
    }
}

                    
?>
<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
  </head>
  <body>
    <header>
          
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>

        <!-- Banner con Logo -->
        <a class="navbar-brand" href="principal.php">
        <!--    <img src="images/img_logo.png" width="64px" height="64px"> -->
            <h1>A&P Finca Raiz</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse" id="nav-content">   
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="principal.php">Cerrar Sesi&oacute;n</a>
            </li>
        </ul>
        </div>
    </nav>
    
    <!-- fin del diseño de la barra de navegación-->    
    </header>

    <div class="container-fluid">
      <section class="main row">
        <article class="col-xs-12 col-sm-8 col-md-9 col-lg-12">
            <div class="flotante"><h3>Registro de usuarios</h3><br>                 
                <form id="loginform" name="registro" method="post" action="<?php $_SERVER['PHP_SELF']?>">
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="nombre" type="text" class="form-control" name="nombre" placeholder="nombre completo" required>                                        
                    </div>
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="apellidos" type="text" class="form-control" name="apellidos" placeholder="Apellidos" required>                                        
                    </div>
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="cedula" type="text" class="form-control" name="cedula" placeholder="Cedula" required>                                        
                    </div>
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="telefono" type="text" class="form-control" name="telefono" placeholder="T&eacute;lefono" required>                                        
                    </div>
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="email" type="text" class="form-control" name="email" placeholder="Email" required>                                        
                    </div>                    
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <select name="perfil" id="perfil" class="form-control" required>
                        <option value="0">-- Selecciona el perfil --</option>
                        <?php
                        $sqlperfil =  $mysqli->query("SELECT `id`,`nombre_perfil`
                              FROM ap_perfil
                              WHERE `activo` = 1");
                        //echo $sqlperfil;
                        while ($resultado = mysqli_fetch_array($sqlperfil)){
                            echo '<option value="'.$resultado[id].'">'.$resultado[nombre_perfil].'</option>';
                        }
                        ?>    
                    </select>
                    </div>
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>                                        
                    </div>
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="con_password" type="password" class="form-control" name="con_password" placeholder="Confirmar password" required>                                        
                    </div>                    
                    <div style="margin-top:10px" class="form-group">
                    <div class="col-sm-12 controls">
                    <button id="btn-login" type="submit" class="btn btn-success">Registrar</a>
                    </div>
                    </div>
                </form>

                  <?php 
                    echo resultBlockSucces($succes);
                    echo resultBlock($errors);
                  ?>
            </div>
        </article>        
      </section>      
    </div>

    <footer >
      <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
           
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="https://co.linkedin.com">
                        <img src="images/linkedin_logo2.png" alt="Linkedin">
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://www.facebook.com">
                        <img src="images/facebook_logo2.png" alt="Facebook">
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://www.instagram.com">
                        <img src="images/instagram_logo2.png" alt="Instagram">
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://www.youtube.com">
                        <img src="images/youtube_logo2.png" alt="Youtube">
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://www.twitter.com">
                        <img src="images/twitter_logo2.png" alt="Twitter">
                    </a>
                </li>
            </ul>
        
      </nav>
        
    </footer>     
      
    <!-- Fin del diseño del banner -->  
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQeury -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
    
    <!-- Initialize Bootstrap functionality -->
    <script>
    // Initialize tooltip component
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })

    // Initialize popover component
    $(function () {
      $('[data-toggle="popover"]').popover()
    })
    </script>
    
  </body>

</html>
