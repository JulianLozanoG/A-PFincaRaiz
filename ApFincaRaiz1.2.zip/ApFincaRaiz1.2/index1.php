<!DOCTYPE html>
<!--
Cliente: A&P Finca Raiz.
Creado por: Interactive group. Julián Lozano.
Fecha: 2017
-->
<?php
$mysqli = new mysqli('localhost', 'root', 'root', 'apfinca_raiz');
require 'funcs/funcs.php';

$errors = array();

if(!empty($_POST)){
    
    //echo 'entro';
    $usuario = $mysqli->real_escape_string($_POST['usuario']);
    $password = $mysqli->real_escape_string($_POST['password']);
    
    if(isNullLogin($usuario, $password)){
        $errors[] = "Debe llenar todos los campos";
    }
    
     if(count($errors == 0)){
        //echo 'entro';
        $inicioSesion = login($usuario, $password);
        var_dump($inicioSesion);
        
        if($inicioSesion < 1 ){
            echo "Inicio de sesión correcto";
        }else {
            $errors[]= "Error en el inicio de sesión";
            
        }
    }
}

?>


<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
  </head>
  <body>
    
    <header>
          
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>

        <!-- Banner con Logo -->
        <a class="navbar-brand" href="principal.php">
        <!--    <img src="images/img_logo.png" width="64px" height="64px"> -->
            <h1>A&P Finca Raiz</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse" id="nav-content">   
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
            <a class="nav-link" href="#">Blog</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="#">Nuestra Empresa</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="#">Contacto</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="index1.php">Iniciar Sesi&oacute;n</a>
            </li>
        </ul>
        </div>
    </nav>
    
    <!-- fin del diseño de la barra de navegación-->    
    </header>  
      
    <!-- Ventana modal para el formulario de Inicio de sesión-->    
    <div id="flotante">        
    <form id="loginform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" autocomplete="off">

        <div style="margin-bottom: 25px" class="input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
            <input id="usuario" type="text" class="form-control" name="usuario" placeholder="C&eacute;dula" required>                                        
        </div>

        <div style="margin-bottom: 25px" class="input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
            <input id="password" type="password" class="form-control" name="password" placeholder="Clave" required>                                        
        </div>

        <div style="margin-top:10px" class="form-group">
            <div class="col-sm-12 controls">
                <button id="btn-login" type="submit" class="btn btn-success">Iniciar Sesi&oacute;n</button>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-12 control">
                <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
                <a href="registro.php">Registrate aqui!</a>
                </div>
            </div>
        </div>    
    </form>
    </div>
         
      
    <footer>
      <div class="container-fluid">
        <h3>Footer</h3>
      </div>
    </footer>
       
    <script src="js/jquery.js" charset="utf-8"></script>
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
    
   
  </body>

</html>

