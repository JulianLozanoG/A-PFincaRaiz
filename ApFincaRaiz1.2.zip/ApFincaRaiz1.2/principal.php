
<!--
Cliente: A&P Finca Raiz.
Creado por: Interactive group. Julián Lozano.
Fecha: 2017
-->

<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <!--<link rel="stylesheet" href="css/style.css">-->
  </head>
  <body>
    <header>
          
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>

        <!-- Brand -->
        <a class="navbar-brand" href="principal.php">
        <!--    <img src="images/img_logo.png" width="64px" height="64px"> -->
            <h1>A&P Finca Raiz</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse" id="nav-content">   
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
            <a class="nav-link" href="#">Blog</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="#">Nuestra Empresa</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="#">Contacto</a>
            </li>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="index.php">Iniciar Sesi&oacute;n</a>
            </li>
        </ul>
        </div>
    </nav>
    
    <!-- fin del diseño de la barra de navegación-->    
    </header>

    <div class="container">
      <section class="main row">
        <article class="col-xs-12 col-sm-8 col-md-9 col-lg-9">
          <h3>Article</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </article>

        <aside class="col-xs-12 col-sm-4 col-md-3 col-lg-3">
          <h3>Aside</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </aside>
      </section>

      <div class="row">
        <div class="color1 col-xs-12 col-sm-6 col-md-3">
          <h3>Columna</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3">
          <h3>Columna</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
        <!-- <div class="clearfix visible-sm-block"></div> -->
        <div class="color1 col-xs-12 col-sm-6 col-md-3">
          <h3>Columna</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3">
          <h3>Columna</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
      </div>
    </div>

    <footer >
      <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
           
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="https://co.linkedin.com">
                        <img src="images/linkedin_logo2.png" alt="Linkedin">
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://www.facebook.com">
                        <img src="images/facebook_logo2.png" alt="Facebook">
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://www.instagram.com">
                        <img src="images/instagram_logo2.png" alt="Instagram">
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://www.youtube.com">
                        <img src="images/youtube_logo2.png" alt="Youtube">
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://www.twitter.com">
                        <img src="images/twitter_logo2.png" alt="Twitter">
                    </a>
                </li>
            </ul>
        
      </nav>
        
    </footer>     
      
      <!-- Fin del diseño del banner -->
<!--      </div>
        
      
    </footer>-->
      
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQeury -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
  </body>

</html>


