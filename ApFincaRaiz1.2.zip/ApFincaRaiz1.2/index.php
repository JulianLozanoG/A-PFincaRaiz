<!DOCTYPE html>
<!--
Cliente: A&P Finca Raiz.
Creado por: Interactive group. Julián Lozano.
Fecha: 2017
-->
<?php
$mysqli = new mysqli('localhost', 'root', 'root', 'apfinca_raiz');
require 'funcs/funcs.php';

$errors = array();

if(!empty($_POST)){
    
    //echo 'entro';
    $usuario = $mysqli->real_escape_string($_POST['usuario']);
    $password = $mysqli->real_escape_string($_POST['password']);
    
    if(isNullLogin($usuario, $password)){
        $errors[] = "Debe llenar todos los campos";
    }
    
     if(count($errors == 0)){
        //echo 'entro';
        $inicioSesion = login($usuario, $password);
        var_dump($inicioSesion);
        
        if($inicioSesion > 0 ){
            echo "Inicio de sesión correcto";
        }else {
            $errors[]= "Error en le inicio de sesión";
            //echo "Falló la preparación: (" . $errormysql . ") ";
        }
    }
}

?>


<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
  </head>
  <body>
    <header>
      <div class="container-fluid">
         <!--<title>A&P Finca Raiz</title>-->
         <h1>A&P Finca Raiz</h1>
      </div>


    </header>
  
    <!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
      
    <script src="js/jquery.js" charset="utf-8"></script>
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQeury -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
    
    <!-- Initialize Bootstrap functionality -->
    <script>
    // Initialize tooltip component
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })

    // Initialize popover component
    $(function () {
      $('[data-toggle="popover"]').popover()
    })
    </script>
  </body>
