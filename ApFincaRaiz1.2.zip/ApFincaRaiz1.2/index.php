<!DOCTYPE html>
<!--
Cliente: A&P Finca Raiz.
Creado por: Interactive group. Julián Lozano.
Fecha: 2017
-->
<?php
$mysqli = new mysqli('localhost', 'root', 'root', 'apfinca_raiz');
require 'funcs/funcs.php';

$errors = array();

if(!empty($_POST)){
    
    //echo 'entro';
    $usuario = $mysqli->real_escape_string($_POST['usuario']);
    $password = $mysqli->real_escape_string($_POST['password']);
    
    if(isNullLogin($usuario, $password)){
        $errors[] = "Debe llenar todos los campos";
    }
    
     if(count($errors == 0)){
        //echo 'entro';
        $inicioSesion = login($usuario, $password);
        var_dump($inicioSesion);
        
        if($inicioSesion > 0 ){
            echo "Inicio de sesión correcto";
        }else {
            $errors[]= "Error en le inicio de sesión";
            //echo "Falló la preparación: (" . $errormysql . ") ";
        }
    }
}

?>


<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
  </head>
  <body>
    <header>
      <div class="container-fluid">
         <!--<title>A&P Finca Raiz</title>-->
         <h1>A&P Finca Raiz</h1>
      </div>


    </header>
      
      <div id="flotante">Inicio de sesi&oacute;n<br>
        <form id="loginform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" autocomplete="off">
							
            <div style="margin-bottom: 25px" class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                <input id="usuario" type="text" class="form-control" name="usuario" placeholder="usuario" required>                                        
            </div>
            
            <div style="margin-bottom: 25px" class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                <input id="password" type="password" class="form-control" name="password" placeholder="password" required>                                        
            </div>
            
            <div style="margin-top:10px" class="form-group">
                <div class="col-sm-12 controls">
                    <button id="btn-login" type="submit" class="btn btn-success">Enviar</a>
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-12 control">
                    <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
                    <a href="registro.php">Registrate aqui!</a>
                    </div>
                </div>
            </div>    
        </form>
    </div>

    <div class="container-fluid">
      <section class="main row">
        <article class="col-xs-12 col-sm-8 col-md-9 col-lg-12">
          <h3>Article</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </article>

      </section>

      <div class="row">
        <div class="color1 col-xs-12 col-sm-6 col-md-3">
          <h3>Columna</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3">
          <h3>Columna</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
        <!-- <div class="clearfix visible-sm-block"></div> -->
        <div class="color1 col-xs-12 col-sm-6 col-md-3">
          <h3>Columna</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3">
          <h3>Columna</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
      </div>
    </div>

    <footer>
      <div class="container-fluid">
        <h3>Footer</h3>
      </div>
    </footer>
       
    <script src="js/jquery.js" charset="utf-8"></script>
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
    
   
  </body>

</html>

